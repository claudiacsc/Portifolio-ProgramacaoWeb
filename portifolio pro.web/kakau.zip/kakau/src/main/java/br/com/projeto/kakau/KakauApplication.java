package br.com.projeto.kakau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KakauApplication {

	public static void main(String[] args) {
		SpringApplication.run(KakauApplication.class, args);
	}

}
