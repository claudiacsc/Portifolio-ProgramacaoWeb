package br.com.projeto.kakau;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakauApplicationTests {

	@Test
	void contextLoads() {
	}

}
